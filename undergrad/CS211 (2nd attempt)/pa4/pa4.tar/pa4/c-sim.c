#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<math.h>

typedef struct{
	int num_tagBits;
	int num_set_indexBits;
	int num_block_offsetBits;
	int decimal_index;
	char *set_index;
	char *tag;
	char *readwrite; //either R or W.
} mem_address; //essentially the struct I'm using for every line in the tracefile arg. 

typedef struct{
	int valid; //valid bit.
	int dirty; //dirty bit, used for WriteBack only.
	int LRU_tstamp; //used for LRU implementation crap.
	int FIFO_tstamp; //used for FIFO implementation crap.
	char* tag;
} cache_line; //the 'atoms' of my cache struct. Form a cache_set.

typedef struct{
	cache_line **lines; //link between a cache_line and a cache_set.
} cache_set; //the 'blocks' of my cache struct. Formed from cache_lines, and form a cache. (like stacking legos).

typedef struct{
	char * assoc; //associativity.
	char * writePol; //write policy.
	char * replacementPol; //replacement policy.
	int hits; //self-explanatory.
	int misses; //self- explan.
	int reads; //self-explan.
	int writes; //self-expaln.
	int cache_size; //self-explanatory.
	int block_size; //self-explanatory.
	int set_size; //the # value gleaned from the associativity arg.
	cache_set **sets; //link between a cache_set and a cache.
} cache;


	cache * catch = NULL; //Initializing my cache, dubbed 'catch' instead of cache so that I don't confuse the two.

//self-explanatory - but for clarity's sake, it essentially malloc's and intializes a temp cache_line, then returns it. (Not doing so puts me at risk for random seg faults).
cache_line *createLine()
{
	cache_line *tmp;
	tmp = malloc(sizeof(cache_line));
	tmp->valid = 0;
	tmp->dirty = 0;
	tmp->tag = (char*)malloc(sizeof(char)*33);
	tmp->LRU_tstamp = 0;
	tmp->FIFO_tstamp = 0;
	return tmp;	
}

//Returns the number of lines in the given trace file.
int getNumLines(FILE *file)
{
	int currLine, totalLines = 0;
	while(currLine != EOF)
	{
		currLine = fgetc(file);
		if(currLine == '\n')
		{
			totalLines++;
		}
	}
	return totalLines;
}

//self-explanatory title for a function; but it verifies of a given number is a power of two or not.
int isPowerOfTwo(int num)
{
	while((num >1) && ((num %2) == 0))
	{
		num /= 2;
	}
	if(num == 1)
	{
		return 1; //true
	}
	else
	{
		return 0; //false
	}	
}

//self-explanatory title; converts a binary input to its respective decimal form.
int binToDec(char *bin)
{
	int num, result, base, rem;
	num = atoi(bin); //converts the char* binary to an int, so I can do my stuff.
	base = 1;
	result = 0;
	while(num >0)
	{
		rem = num % 10;
		result = result + rem*base;
		num /= 10;
		base*=2;	
	}
	return result;
}

//converts a hexadecimal address to its respective binary form.
char *hexToBin(char *address)
{
	int i;
	char *ret = malloc(sizeof(char) * 33); //malloc's the return value; this will be continuously added upon in the below for-loop.
	for(i = 2; i < strlen(address); i++)
	{
		if(address[i] == '0')
		{
			strcat(ret, "0000");
		}
		else if(address[i] == '1')
		{
			strcat(ret, "0001");
		}
		else if(address[i] == '2')
		{
			strcat(ret, "0010");
		}
		else if(address[i] == '3')
		{
			strcat(ret, "0011");
		}
		else if(address[i] == '4')
		{
			strcat(ret, "0100");
		}
		else if(address[i] == '5')
		{
			strcat(ret, "0101");
		}
		else if(address[i] == '6')
		{
			strcat(ret, "0110");
		}
		else if(address[i] == '7')
		{
			strcat(ret, "0111");
		}
		else if(address[i] == '8')
		{
			strcat(ret, "1000");
		}
		else if(address[i] == '9')
		{
			strcat(ret, "1001");
		}
		else if(address[i] == 'a')
		{
			strcat(ret, "1010");
		}
		else if(address[i] == 'b')
		{
			strcat(ret, "1011");
		}
		else if(address[i] == 'c')
		{
			strcat(ret, "1100");
		}
		else if(address[i] == 'd')
		{
			strcat(ret, "1101");
		}
		else if(address[i] == 'e')
		{
			strcat(ret, "1110");
		}
		else //last remaining edge case: 'f'.
		{
			strcat(ret, "1111");
		}
	}
	strcat(ret, "\0");
	return ret;
}

//literally adds a character to the end of a given string of chars.
void append(char * str, char c)
{
	str[strlen(str)] = c;
	str[strlen(str)+1] = '\0';
}
//calculates the block offsetbits
int calcNumBlockOffsetBits()
{
	return (int)(log((double)catch->block_size)/log(2.0));
}
//calculates the indexbits
int calcNumSetIndexBits()
{
	return (int)(log((double)catch->set_size)/log(2.0));
}

//from lecture; returns the tag bits (which is the line's length - indexbits - offsetbits.
int calcNumTagBits(int memLength, mem_address *mem)
{
	return memLength - mem->num_set_indexBits - mem->num_block_offsetBits;
}
//self-explanatory name for a method.
void createSet(cache_set *set)
{
	set->lines = malloc(catch->set_size * sizeof(cache_line));	
}

//Creates a 'cold' cache, which is essentially a cache where all entries are invalid / empty.
void initCache()
{
	int i, j;
	catch->sets = malloc(catch->set_size * sizeof(cache_set));
	for(i = 0; i < catch->set_size; i++)
	{
		catch->sets[i] = malloc(sizeof(cache_set));
		createSet(catch->sets[i]);
		for(j = 0; j < catch->set_size; j++)
		{
			catch->sets[i]->lines[j] = createLine();
		}
	}
}

//updates the values in a single address.
void updateAddressValues(int memLength, mem_address *mem, char *addr)
{
	int i;
	mem->num_block_offsetBits = calcNumBlockOffsetBits();
	mem->num_set_indexBits = calcNumSetIndexBits();
	mem->num_tagBits = calcNumTagBits(memLength, mem);
	mem->tag = malloc(mem->num_tagBits * sizeof(char) +1); //reallocates memory for the tag value (in accordance to the recalculation.
	mem->set_index = malloc(mem->num_set_indexBits * sizeof(char) +1); //reallocates memory for the set_index value (in accordance to the recalculation.
	for(i = 0; i < mem->num_tagBits; i++)
	{
		append(mem->tag, addr[i]); //appends the converted binary value taken from the tracefile to the current mem_address struct's tag.
	}
	while(i < (mem->num_set_indexBits + mem->num_tagBits))
	{
		append(mem->set_index, addr[i]); //replacement.
		i++;	
	}
	mem->decimal_index = binToDec(mem->set_index); //converts the value to binary, and stores it in a decimal_index variable (to be used indefinitely below).
}

//updates the cache lines in terms of an LRU algorithm.
//Whenever a replacement is needed, we call this func to basically set the line with the highest tstamp value back to 0.
void updateLRU(mem_address *mem)
{
	int i, hi;
	
	int j, hi2 = 0, lru = 0; //values used to find my least recently used value (the one with the highest LRU_tstamp).
	for(j = 0; j < catch->set_size; j++) //iterates through the entire cache to find the line with the highest LRU tstamp value (the one we're gonna harvest).
	{
		if(catch->sets[mem->decimal_index]->lines[j]->LRU_tstamp > lru)
		{
			lru = catch->sets[mem->decimal_index]->lines[j]->LRU_tstamp;
			hi2 = j;
		}
	}

	hi = hi2; //found it!

	for(i = 0; i < catch->set_size; i++)
	{
		catch->sets[mem->decimal_index]->lines[i]->LRU_tstamp++; //increments all the other lines' LRU timestamps by one..
	}
	catch->sets[mem->decimal_index]->lines[hi]->LRU_tstamp = 0; //resets the most recently used index.
}

//the FIFO version of updateLRU (Not really much different, except I don't need to bother resetting the highest value. (I'll just take that line (which is by nature the 'oldest', and replace it with a newbie line from memory (tracefile) ).
void updateFIFO (mem_address *mem)
{
	int i;
	for(i = 0; i < catch->set_size; i++)
	{
		catch->sets[mem->decimal_index]->lines[i]->FIFO_tstamp++;
	}
}

//LRU WriteBack implementation.
void LRUWriteBack(mem_address *mem)
{
	int i, hi = 0, index = 0;
	for(i = 0; i < catch->set_size; i++)
	{
		if(catch->sets[mem->decimal_index]->lines[i]->valid == 0)
		{
			strcpy(catch->sets[mem->decimal_index]->lines[i]->tag, mem->tag); //copies over the line from cache to main memory.
			catch->sets[mem->decimal_index]->lines[i]->valid = 1; //sets the valid bit for said line to 1.
			if(catch->sets[mem->decimal_index]->lines[hi]->dirty == 1)
			{
				catch->writes++; //a write has occurred.
			}
			if(strcmp(mem->readwrite, "R") == 0)
			{
				catch->sets[mem->decimal_index]->lines[hi]->dirty = 0; //makrs that the line was 'read'.
			}
			else
			{
				catch->sets[mem->decimal_index]->lines[hi]->dirty = 1;
			}
			updateLRU(mem);
			return;
		}
		if(catch->sets[mem->decimal_index]->lines[i]->LRU_tstamp > index)
		{
			index = catch->sets[mem->decimal_index]->lines[i]->LRU_tstamp;
			hi = i; //found the least recently used index.
		}
	}
	if(catch->sets[mem->decimal_index]->lines[hi]->dirty == 1)
	{
		catch->writes++;
	}
	if(strcmp(mem->readwrite, "R") == 0) //a read is found.
	{
		catch->sets[mem->decimal_index]->lines[hi]->dirty = 0;
	}
	else
	{
		catch->sets[mem->decimal_index]->lines[hi]->dirty = 1;
	}
	catch->sets[mem->decimal_index]->lines[hi]->tag = mem->tag;
	updateLRU(mem);
	
}

//FIFO implementation of writeback. Pretty much the same as that of LRU, since the only real difference in my implementation (between LRU and FIFO) is the way I treat the timestamps.
void FIFOWriteBack(mem_address *mem)
{
	int i, hi = 0, index = 0;
	for(i = 0; i < catch->set_size; i++)
	{
		if(catch->sets[mem->decimal_index]->lines[i]->valid == 0)
		{
			strcpy(catch->sets[mem->decimal_index]->lines[i]->tag, mem->tag);
			catch->sets[mem->decimal_index]->lines[i]->valid = 1;
			if(catch->sets[mem->decimal_index]->lines[hi]->dirty == 1)
			{
				catch->writes++; //a write has occurred.
			}
			if(strcmp(mem->readwrite, "R") == 0)
			{
				catch->sets[mem->decimal_index]->lines[hi]->dirty = 0; //makrs that the line was 'read'.
			}
			else
			{
				catch->sets[mem->decimal_index]->lines[hi]->dirty = 1;
			}
			updateFIFO(mem);
			return;
		}
		if(catch->sets[mem->decimal_index]->lines[i]->FIFO_tstamp > index) //iterates through everything to find the line with the highest tstamp value.
		{	
			index = catch->sets[mem->decimal_index]->lines[i]->FIFO_tstamp;
			hi = i;
		}	
	}
	if(catch->sets[mem->decimal_index]->lines[hi]->dirty == 1) //write found.
	{
		catch->writes++;
	}
	if(strcmp(mem->readwrite, "R") == 0)
	{
		catch->sets[mem->decimal_index]->lines[hi]->dirty = 0;
	}
	else
	{
		catch->sets[mem->decimal_index]->lines[hi]->dirty = 1;
	}
	catch->sets[mem->decimal_index]->lines[hi]->tag = mem->tag; //replaces the line with the highest tstamp value (meaning that it survived in the cache the longest) with the new value from the tracefile.
	updateFIFO(mem);
}

//for the 'wt' argument in write policy.
void writeBack(mem_address *mem)
{
	int i, j; //for-loop iterators.
	for(i = 0; i < catch->set_size; i++)
	{
		int validity = catch->sets[mem->decimal_index]->lines[i]->valid;
		char* mainMemTag = mem->tag;
		if((strcmp(mainMemTag, catch->sets[mem->decimal_index]->lines[i]->tag) == 0) && validity == 1) //compares cache line and memory's tag for equality, and if the validity bit is set to 1.
		{
			catch->hits++; //if the aforementioned is true, a hit has occurred!
			catch->sets[mem->decimal_index]->lines[i]->LRU_tstamp = 0; //setting up LRU timestamp for LRUWriteBack().
			catch->sets[mem->decimal_index]->lines[i]->FIFO_tstamp = 0; //setting up FIFO for FIFOWriteBack().
			if(strcmp(mem->readwrite, "W") == 0)
			{
				catch->sets[mem->decimal_index]->lines[i]->dirty = 1; //setting the dirty bit to 1, so I know that I can take it out when it is hit again.
			}
			for(j = 0; j < catch->set_size; j++)
			{
				if( j!= i)
				{
					catch->sets[mem->decimal_index]->lines[j]->LRU_tstamp++; //every other line EXCEPT the special guy with the highest tstamp value gets promoted by one.
				}
			}
			return;
		}
	}
	catch->misses++; //runs if a hit does not occur.
	catch->reads++; //and if a write/dirty-bit-initiation did not occur, then a read certainly did.

	if(strcmp(catch->replacementPol, "LRU") == 0) //checks the cache if doing LRU...
	{
		LRUWriteBack(mem);
	}
	else
	{
		FIFOWriteBack(mem); //or FIFO.
	}
}

//LRU implementation of a write through.
void LRUWriteThrough(mem_address *mem)
{
	int i, hi = 0, index = 0; //variables for my for-loop iterator, highest LRU-tstamp, and most recently used stamp.
	for(i = 0; i < catch->set_size; i++)
	{
		if(catch->sets[mem->decimal_index]->lines[i]->valid == 0)
		{
			strcpy(catch->sets[mem->decimal_index]->lines[i]->tag, mem->tag); //copies the line from the cache to main memory.
			catch->sets[mem->decimal_index]->lines[i]->valid = 1; //sets the validity bit to 1 for the cache version of the line.
			updateLRU(mem); //reshuffles everything for LRU.
			return;
		}
		else if(catch->sets[mem->decimal_index]->lines[i]->LRU_tstamp > index)
		{
			index = catch->sets[mem->decimal_index]->lines[i]->LRU_tstamp;
			hi = i; //the new 'high' LRU index is now set.
		}
	}
	catch->sets[mem->decimal_index]->lines[hi]->tag = mem->tag; //moves the line with the highest LRU time stamp over from main memory.
	updateLRU(mem); //re-shuffles in order to figure out which line is where for LRU.
}


//FIFO implementation of a write through. Virtually identical to LRU's writethrough.
void FIFOWriteThrough(mem_address *mem)
{
	int i, hi = 0, index = 0; 
	for(i = 0; i < catch->set_size; i++)
	{
		if(catch->sets[mem->decimal_index]->lines[i]->valid == 0)
		{
			strcpy(catch->sets[mem->decimal_index]->lines[i]->tag, mem->tag);
			catch->sets[mem->decimal_index]->lines[i]->valid = 1;
			updateFIFO(mem);
			return;
		}
		else if(catch->sets[mem->decimal_index]->lines[i]->FIFO_tstamp > index)
		{
			index = catch->sets[mem->decimal_index]->lines[i]->FIFO_tstamp;
			hi = i;
		}
	}
	catch->sets[mem->decimal_index]->lines[hi]->tag = mem->tag; //replaces the 'oldest' line with a new one from main memory (aka the trace file, lol).
	updateFIFO(mem);
}

//the 'wt' for the write policy argument.
void writeThrough(mem_address *mem)
{
	int i, j;
	for(i = 0; i < catch->set_size; i++) //iterates through everything.
	{
		int validity = catch->sets[mem->decimal_index]->lines[i]->valid;
		char* mainMemTag = mem->tag;
		if((strcmp(mainMemTag, catch->sets[mem->decimal_index]->lines[i]->tag) == 0) && validity == 1) //checks if tags match and valid bit is set to 1.
		{
			catch->hits++; //if tags match and validity checks out, score a hit.
			
			catch->sets[mem->decimal_index]->lines[i]->LRU_tstamp = 0; //sets LRU tstamp (used for LRU implementation) to 0.
			catch->sets[mem->decimal_index]->lines[i]->FIFO_tstamp = 0; //sets FIFO tstamp (used for FIFO implementation) to 0.
			if(strcmp(mem->readwrite, "W") == 0) //if the readwrite was set to W, then increment writes.
			{
				catch->writes++; //writes gets incremented.
			}		
			for(j = 0; j < catch->set_size; j++)
			{
				if(j != i)
				{
					catch->sets[mem->decimal_index]->lines[j]->LRU_tstamp++; //all other LRU indices get incremented by one (this ensures that I can keep track of the 'least recently' accessed line.
				}			
			}
			return;
		}
	}
	catch->misses++; //if not a hit, then surely a miss.
	catch->reads++; //if not a write, then a read.
	
	if(strcmp(mem->readwrite, "W") == 0)
	{
		catch->writes++;
	}
	if(strcmp(catch->replacementPol, "LRU") == 0) //checks the cache if doing LRU...
	{
		LRUWriteThrough(mem);
	}
	else
	{
		FIFOWriteThrough(mem); //or FIFO.
	}
}

//parses all the lines in a given trace file, and then directs them according to write policy.
void updateCache(FILE * file, int numLines)
{
	int memLength;
	char ip[12], rw[2], address[11], *bin;
	mem_address * mem;
	while (fscanf(file, "%s %s %s", ip, rw, address) != EOF && strcmp(ip, "#eof") != 0)
	{
		mem = malloc(sizeof(mem_address));

		mem->num_tagBits = 0;
		mem->num_set_indexBits = 0;
		mem->num_block_offsetBits = 0;
		mem->decimal_index = 0;
		mem->set_index = NULL;
		mem->tag = NULL;
		mem->readwrite = NULL;

		if(strcmp(rw, "W") == 0) //checks for writes.
		{
			mem->readwrite = "W";
		}
		else
		{
			mem->readwrite = "R";
		}
		bin = hexToBin(address);
		memLength = strlen(bin);

		updateAddressValues(memLength, mem, bin);

		if(strcmp(catch->writePol, "wt") == 0)
		{
			writeThrough(mem);
		}
		else //only other option here is "wb".
		{
			writeBack(mem);
		}
		free(bin);
		free(mem);
			
	}
}

//the best part of writing this program-freeing everything.
void freeEverything() 
{
	int i, j; //my beloved for-loop vars.

	//frees everything from inside-out.
	for(i = 0; i < catch->set_size; i++)
	{
		for(j = 0; j < catch->set_size; j++)
		{
			free(catch->sets[i]->lines[j]->tag); 
			free(catch->sets[i]->lines[j]);
		}
		free(catch->sets[i]->lines);
		free(catch->sets[i]);
	}
}

//Template is:
// ./c-sim <cache size> <associativity> <block size> <replacement_policy> <write_policy> <trace file>
int main(int argc, char *argv[])
{
	int cacheSize, setSize, blockSize; //my first, second (part of it), and third arguments, respectively.
	char *associativity, *replacementPol, *writePol; //my second,fourth and fifth argument values, respectively.
	FILE* file; //my sixth, and last argument.	

	int numLines; //self-explanatory.
	
	cacheSize = atoi(argv[1]);
	associativity = argv[2];	
	blockSize = atoi(argv[3]);
	replacementPol = argv[4];
	writePol = argv[5];
	file = fopen(argv[6], "r"); 

	//Initializing the cache (to prevent seg faults).	
	catch = malloc(sizeof(cache));
	catch->assoc = NULL;
	catch->writePol = NULL;
	catch->replacementPol = NULL;
	catch->sets = NULL;
	catch->hits = 0;
	catch->misses = 0;
	catch->reads = 0;
	catch->writes= 0;
	catch->cache_size = 0;
	catch->block_size = 0;
	catch->set_size = 0;


	//if not exactly all six arguments are given, throw an error.
	if(argc != 7)
	{
		printf("error; insufficient arguments given.\n");
		return 0; //shit hit the fan.
	}
	else
	{
		if(isPowerOfTwo(cacheSize) != 1 || cacheSize <= 0)
		{
			printf("Invalid cache size input.\n");
			return 0; //cache size is not a power of 2, or it's <=0 (which is not possible).
		}
		else
		{
			catch->cache_size = cacheSize;
		}
		
		if(strcmp(associativity, "direct") == 0)
		{		
			setSize = 1;
		}
		else if (strcmp(associativity, "assoc") == 0)
		{
			setSize = cacheSize / blockSize; //assuming that both cache and block args are powers of 2.
		}
		else
		{
			if(!strncmp(argv[2], "assoc:", 6))
			{	
				setSize = atoi(strchr(argv[2], ':')+1);
			}
			else
			{
				printf("error; invalid input for associativity\n");
				return 0; //the user screwed up the input for assoc.
			}
		}

		if(isPowerOfTwo(setSize) != 1)
		{
			printf("error; associativity value is not a power of 2.\n");
			return 0; //the setsize is not a power of 2.
		}
		else
		{
			catch->set_size = setSize;
			catch->assoc = associativity;
		}
 
		if(isPowerOfTwo(blockSize) != 1)
		{
			printf("error; block size is not a power of 2.\n");
			return 0; //the number inserted was not a power of 2.
		}
		else
		{
			catch->block_size = blockSize;
		}

		if(strcmp(replacementPol, "LRU") == 0)
		{
			catch->replacementPol = replacementPol;	
				}
		else if (strcmp(replacementPol, "FIFO") == 0)
		{
			catch->replacementPol = replacementPol;	
		}
		else	
		{
			printf("error; improper input for replacement policy.\n");
			return 0; //bad input for <replacement_policy>
		}

		if(strcmp(writePol, "wt") == 0)
		{
			catch->writePol = writePol;	
		}
		else if(strcmp(writePol, "wb") == 0)
		{
			catch->writePol = writePol;
		}
		else	
		{
			printf("error; improper input for write policy.\n");
			return 0; //bad input for <write policy>.
		}
		
		initCache(); //creates a clean cache whose entries are all empty.	

		if(file == NULL)
		{
			printf("error; no file found for trace file.\n");
			return 0; //no tracefile found.
		}
		else
		{
	
			numLines = getNumLines(file);
			fclose(file);
			file = fopen(argv[6], "r");
			updateCache(file, numLines);

			printf("Memory reads: %d\n", catch->reads); //cache reads.
			printf("Memory writes: %d\n", catch->writes); //cache writes.
			printf("Cache hits: %d\n", catch->hits); //cache hits.
			printf("Cache misses: %d\n", catch->misses); //cache misses.

		}
			freeEverything(); //fly free, Willy!		
	}
	return 1; //all is well.	
}
