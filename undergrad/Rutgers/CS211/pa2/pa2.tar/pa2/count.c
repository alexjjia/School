#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<math.h>

int count = 0;
struct node
{
	char *data;
	struct node *next;
};

struct hashTable
{
	struct node ** table;
	size_t size;
};

//converts a hex to an int.
unsigned int hexToInt(char* hex)
{
	return (unsigned int)strtol(hex, NULL, 16);
}

//The most generic hash function in existence.
size_t hash(char * key, size_t size)
{
	return hexToInt(key) % size;	
}

//Inserts the crap into a hash table.
int insert (struct hashTable * htable, char *key)
{
	struct node * tempNode;
	size_t index = hash(key, htable->size); //contains hashed index (between 0 to 999)
	
	//look for a preexisting node of the same value
	//this is where we get our 'count' value.

	if(1) //will always run to check for duplicates.
	{
		tempNode = htable->table[index];
		while(tempNode != NULL)
		{
			if(strcmp(key, tempNode->data) == 0)
			{
				return 0; //why bother entering a duplicate value?
			}
			tempNode = tempNode->next;
		}
	}
	//Insert a new node, presumably with a unique value.
	count++; //count is incremented by one.
	tempNode = malloc(sizeof *tempNode);
	
	if(tempNode == NULL)
	{
		return 0; //shit hit the fan.
	}
	tempNode->data = key;
	tempNode->next = htable->table[index];
	htable->table[index] = tempNode;
	return 1; //all good.
}

//Checks if a given string is a hex or not.
int checkIfHex(char *hex)
{
	if(hex[strspn(hex, "0123456789aAbBcCdDeEfF")] == 0)
	{
		return 1; //true.
	}
		return 0; //false otherwise.
}

//Self explanatory.
struct hashTable* createHashTable(size_t nsize)
{
	struct hashTable* htable = malloc(sizeof *htable);
	htable->size = nsize;
	htable->table = malloc(sizeof(struct node*) * htable->size);
	
	return htable;
}

int main(int argc, char *argv[])
{
	char buffer[20];
	//initialize my hash table, with initial size of 1000, and load factor threshold of 0.75
	struct hashTable* hTable = createHashTable(100000000);
 
	//if more or less than one argument is given, throw an error.
	if(argc != 2)
	{
		printf("error\n");
	}
	else
	{
		FILE* file = fopen(argv[1], "r");
	//if the file is not found, throw an error.
		if(file == NULL)
		{
			printf("error\n");
			return 0; //return code for an error.
		}
		//reads file line by line, parsing by the template '0x#blahblah'.
		//Note: #blahblah refers to the string of chars after the 0x.
		while(fscanf(file, "\n0x%s", buffer) !=EOF)
		{
			if(checkIfHex(buffer) == 1)// 1 means true in this case
			{	
				insert(hTable, buffer);
			}
			//else, it is ignored.
		}
	//parse through file, incrementing count wherever needed.
	fclose(file);
	}
	printf("%d\n",count);	//the one output we actually care about.
	return 1; //all is well.
}
