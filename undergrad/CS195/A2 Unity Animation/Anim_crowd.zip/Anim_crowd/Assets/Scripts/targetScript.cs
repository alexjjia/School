﻿using UnityEngine;
using System.Collections;

public class targetScript : MonoBehaviour {
    public Transform target;
    public NavMeshAgent agent;

    void Update()
    {
        if (Input.GetMouseButtonDown(0))
        {
            RaycastHit hit;
            Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
            if (Physics.Raycast(ray, out hit, 100))
            {
                target.position = hit.point;
            }
        }
        agent.SetDestination(target.position);
    }
}
