﻿using UnityEngine;
using System.Collections;

public class CameraController : MonoBehaviour {
    public GameObject player;
    //public float speed;
    Vector3 offset;

    void Start()
    {
        offset = transform.position;
      //  eulerPos = new Vector3(camera.transform.eulerAngles.x, camera.transform.eulerAngles.y, camera.transform.eulerAngles.z);
    }

    void Update()
    {
       // transform.position = player.transform.position + offset;
        if (Input.GetMouseButtonDown(0))
        { // if left button pressed...
            Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
            RaycastHit hit;
            if (Physics.Raycast(ray, out hit))
            {
                // the object identified by hit.transform was clicked
                // do whatever you want
                if (hit.transform.gameObject.CompareTag("Bot"))
                {
                    player = hit.transform.gameObject;
                    UnityStandardAssets.Characters.ThirdPerson.AICharacterControl script = player.GetComponent<UnityStandardAssets.Characters.ThirdPerson.AICharacterControl > ();
                    if (script.isSelected != true)
                    {
                        script.isSelected = true;
                    }
                    else
                    {
                        script.isSelected = false;
                    }

                }
            }
        }
    }
    // Update is called once per frame
}
