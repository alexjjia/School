#ifndef _MYSTERY_H_
#define _MYSTERY_H_

main(int argc, char* argv[])

#endif /* _MYSTERY_H_ */
