#ifndef _FORMULA_H_
#define _FORMULA_H_

main(int argc, char* argv[])

#endif /* _FORMULA_H_ */
